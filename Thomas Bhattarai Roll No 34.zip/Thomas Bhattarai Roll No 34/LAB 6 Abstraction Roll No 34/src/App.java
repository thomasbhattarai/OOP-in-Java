public class App {
    public static void main(String[] args) throws Exception {
        Circle c = new Circle(); 
        c.draw(); // Output: Drawing Circle
     }
  }
abstract class Shape {
    abstract void draw(); // Abstract method
}
class Circle extends Shape {
    void draw() {
        System.out.println("Drawing Circle");
    }
}
class Rectangle extends Shape {
    void draw() {
        System.out.println("Drawing Rectangle");
    }
}